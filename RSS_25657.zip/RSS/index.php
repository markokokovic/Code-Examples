<!DOCTYPE html>
<html>
<head>
<title>RSS servis</title>
<meta charset="UTF-8">
<style>
.post {
	width:300px;
	float: left;
	height: 300px;
	background-color: yellow;
	margin: 5px;
	}
</style>
</head>
<body>
<form action="index.php" method="POST">
	<select name='rss'>
	<?php
	$xml=simplexml_load_file("url.xml") or die("Error: Cannot create object");
foreach($xml->children() as $adresa) { 
    echo "<option value='".$adresa->url . "'>".$adresa->name."</option>"; 
     } 
?>
	
	
	</select>
	<input type="submit" value="RSS" />
</form>

<?php

	include_once 'getrss.php';
	if(isset($_POST['rss'])){
	$link = $_POST['rss'];
	$posts = getRSS($link);
	foreach($posts as $post){
			echo "<div class='post'>";
				echo "<h3>" . $post['title'] . "</h3>";
				echo "<p>" . $post['description'] . "</p>";
				echo "<i>" . $post['pubDate'] . "</i>";
				echo "<a href='".$post['link']."'>Saznaj vise</a>";
			echo "</div>";
		
		}
	}
	
	
?>

<div class="post">
</div>



</body>
</html>