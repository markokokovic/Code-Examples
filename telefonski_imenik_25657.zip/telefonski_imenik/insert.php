<html>
    <head>
        <title>Telefonski imenik</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <div id="okvir">
            <div id="pretraga">
                <img src='img/search.png' alt='Slika'>
				<a href="index.php"><img src="img/search.png" height="50px" title="Search"></a>
				<a href="remove.php"><img src="img/remove.jpg" height="50px" title="Remove contact"></a>
                <form action="#" method="POST">
				   <label>Ime:<br/>
                  <input type="text" name="fname"> 
				  <label>Prezime:<br/>
                  <input type="text" name="lname"> 
				  <label>Telefon:<br/>
                  <input type="text" name="tel"> <br>
				  <input type="submit" name="insert" value="Insert"><br>
                </form>
				
				
				
            </div>
			<?php
			if(isset($_POST['insert'])){
			if(isset($_POST['fname']) and isset($_POST['lname']) and isset($_POST['tel'])){
			     if(!empty($_POST['fname']) and ($_POST['lname'])and ($_POST['tel'])){
					 $fname = trim($_POST['fname']);
					 $lname = trim($_POST['lname']);
					 $tel = trim($_POST['tel']);
					 require 'conection.php';
					 $fname = mysqli_real_escape_string($conn,$fname);
					 $lname = mysqli_real_escape_string($conn,$lname);
					 $tel = mysqli_real_escape_string($conn,$tel);
					 
					 $query = "INSERT INTO tabela (ime, prezime, tel) VALUES ('{$fname}','{$lname}','{$tel}')";
					 if(mysqli_query($conn, $query)=== true){
						echo "Novi kontakt kreiran!"; 
					 }else{
						 echo "Greska";
					 }
					 
				 }else{
					 echo "Sva polja moraju biti popunjena!";
				 }
				
			}else{
				echo "Sva polja moraju biti popunjena!!!";
			}
			}
			
			
			
			?>
			
			
			
        </div>
    </body>
</html>