<html>
<a href="index.php">Pretraga</a>
<a href="delete.php">Brisanje</a>
<a href="insert.php">Dodavanje</a>
</html>