<?php 
include_once 'conection.php';


		//poziv(pitanje) bazi da selektuje redove * je sve
		//ne zavisi od uslova
		$query = "SELECT * FROM tabela";
		
		//rukovanje povratnim rezultatom, funkcija za postavljanje pitanja
		
		$result = mysqli_query($conn,$query);
		
		
		
		//promenljiva $conn je veza i pvi parametar a pitanje je $query
		//provjera rezultata da li je vece od 0
		if(mysqli_num_rows($result)>0){
			while($r = mysqli_fetch_assoc($result)){
				echo "<div class='rezultat'>";
				echo "<img src='img/User.png'/>";
				echo "Ime: ". $r['ime'] ." <br>";
				echo "Prezime: ".$r['prezime']   ." <br>";
				echo "Tel: ". $r['tel']. "<br>"  ;
				echo "<a href='delete.php?id=".$r['id']."'>Obrisi</a>";
				echo "</div>";
				
				//prepisan div tag koji zamjenjuje izbacivanje niza
				//samo se postave indexi
				
				
			}
		}else{
			echo "nema rezultata pretrage";
		}
		if(isset($_GET['id'])){
			$id = mysqli_real_escape_string($conn, $_GET['id']);
			$query = "DELETE FROM tabela WHERE id = {$id}";
			mysqli_query($conn,$query);
			if(mysqli_affected_rows($conn) > 0){
				header('Location: delete.php');
				echo "Korisnik je uklonjen";
			}else{
				echo "Nije uklonjen kontakt.";
			}
		}
		
	

?>