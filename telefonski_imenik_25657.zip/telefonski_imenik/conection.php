<?php
$host = "localhost";
$name = "root";
$pass = "";
$dbName = "phonebook";






$conn = mysqli_connect($host,$name,$pass,$dbName);

if(!$conn){
	die("Problem sa konekcijom, obratite se administratoru!". mysqli_connect_error($conn));
}


?>