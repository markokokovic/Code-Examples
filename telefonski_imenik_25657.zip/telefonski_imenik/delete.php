<html>
    <head>
        <title>Telefonski imenik</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <div id="okvir">
            <div id="pretraga">
                <img src='img/search.png' alt='Slika'>
               
				<?php include_once 'linkovi.php'; 
				//inkludovanje dodatnih opcija kroz linkove
				?>
				
            </div>
			<?php include_once 'remove.php'?>
			
			
        </div>
    </body>
</html>