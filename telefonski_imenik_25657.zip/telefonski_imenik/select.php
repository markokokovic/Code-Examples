<?php 
include_once 'conection.php';

if(isset($_GET['kriterijum'])){
	$kriterijum = trim($_GET['kriterijum']);
	if(!empty($kriterijum)){
		//zastita od mysql injectiona
		$kriterijum = mysqli_real_escape_string($conn,$kriterijum);
		//poziv(pitanje) bazi da selektuje redove * je sve
		
		$query = "SELECT * FROM tabela WHERE ime LIKE '%{$kriterijum}%' OR prezime LIKE '%{$kriterijum}%'";
		
		//rukovanje povratnim rezultatom, funkcija za postavljanje pitanja
		
		$result = mysqli_query($conn,$query);
		
		
		
		//promenljiva $conn je veza i pvi parametar a pitanje je $query
		//provjera rezultata da li je vece od 0
		if(mysqli_num_rows($result)>0){
			while($r = mysqli_fetch_assoc($result)){
				echo "<div class='rezultat'>";
				echo "<img src='img/User.png'/>";
				echo "Ime: ". $r['ime'] ." <br>";
				echo "Prezime: ".$r['prezime']   ." <br>";
				echo "Tel: ". $r['tel']    ;
				echo "</div>";
				//prepisan div tag koji zamjenjuje izbacivanje niza
				//samo se postave indexi
				
				
			}
		}else{
			echo "nema rezultata pretrage";
		}
		
	}else{
		echo "Kriterijum ne sme biti prazan.";
	}
	
}

?>

			
			