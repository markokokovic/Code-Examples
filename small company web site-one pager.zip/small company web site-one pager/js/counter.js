//ADD COUNTER
$(document).ready(function(){
    $('.counter-num').counterUp({
    delay: 10,
    time: 2000
    })
});
    
 $(document).ready(function() {
    'use strict';
    new WOW().init();
    
    });   

