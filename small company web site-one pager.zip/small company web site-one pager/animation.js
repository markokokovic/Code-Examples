//ADD ANIMATION INITIALIZE WOO

$(document).ready(function() {
    'use strict';
    new WOW().init();
    
    });