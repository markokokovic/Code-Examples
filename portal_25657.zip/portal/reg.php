<?php
session_start();
if(isset($_SESSION['userSession'])!="")
{
 header("Location: home.php");
}
include_once 'dbconnect.php';

if(isset($_POST['registracija']))
{
 $uname = $MySQLi_CON->real_escape_string(trim($_POST['user_name']));
 $email = $MySQLi_CON->real_escape_string(trim($_POST['mail']));
 $upass = $MySQLi_CON->real_escape_string(trim($_POST['pass']));
 
 
 
 $check_email = $MySQLi_CON->query("SELECT e_mail FROM korisnik WHERE e_mail='$email'");
 $count=$check_email->num_rows;
 
 if($count==0){
  
  
  $query = "INSERT INTO korisnik(korisnicko_ime,e_mail,lozinka) VALUES('$uname','$email','$upass')";

  
  if($MySQLi_CON->query($query))
  {
   $msg = "<div class='alert alert-success'>
      <span class='glyphicon glyphicon-info-sign'></span> &nbsp; successfully registered !
     </div>";
  }
  else
  {
   $msg = "<div class='alert alert-danger'>
      <span class='glyphicon glyphicon-info-sign'></span> &nbsp; error while registering !
     </div>";
  }
 }
 else{
  
  
  $msg = "<div class='alert alert-danger'>
     <span class='glyphicon glyphicon-info-sign'></span> &nbsp; sorry email already taken !
    </div>";
   
 }
 
 $MySQLi_CON->close();
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Registracija</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style>
section {
	
	background-color:rgba(153,0,0,0);
}
article {
	background-color:rgba(153,0,0,0);
}
#info {
	text-align:center;
	color:rgba(153,0,0,0.7);
	font-size:20px;
	}
#button {
	padding:3px 42px;
	font-size:18px;
	margin: 5px 0 0 0;
	}
input {
	padding: 5px;
	
	}
</style>
</head>

<body>

<div id="wrapper">
        
        <?php
        require('header.inc');
        
        ?>
        
      
        
        
       
        <article>
        
        
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST" id="registracija">
        <h2>Sign up.</h2><hr />
        <label>Ime*:</label><br>
        <input type="text" name="ime" placeholder="Unesite svoje ime.."><br><br>
        <label>Prezime*:</label><br>
        <input type="text" name="prezime" placeholder="Unesite svoje prezime.."><br><br>
        <label>E-mail*:</label><br>
        <input type="text" name="mail" placeholder="Unesite svoj e-mail.."><br><br>
        <label>Korisničko ime*:</label><br>
        <input type="text" name="user_name" placeholder="Unesite svoje korisničko ime.."><br><br>
        <label>Lozinka*:</label><br>
        <input type="password" name="pass" placeholder="Unesite lozinku"><br>
        <input id="button" type="submit" name="registracija" value="Registracija">
        
        
        
        
        </form>
       


        
        </article>
        
        <?php
		/*
		  
               //Konekcija ka bazi
       $dsn = 
            "mysql:host=127.0.0.1;dbname=portal;charset=utf8";

       try{
               //tunel ka bazi, konekcija, username,pass
       $pdo = new PDO($dsn,"root","");	
	
       }catch(PDOException $e){
	
       die($e->getMessage());	
       }
		
		
		
        //unos novog korisnika u bazu
		if(isset($_POST['registracija'])){
			if(isset($_POST['ime']) and isset($_POST['prezime']) and isset($_POST['mail']) and isset($_POST['user_name']) and isset($_POST['pass'])){
				if(!empty($_POST['ime']) and ($_POST['prezime']) and ($_POST['mail']) and ($_POST['user_name']) and ($_POST['pass'])){
					 $ime = trim($_POST['ime']);
					  $prezime = trim($_POST['prezime']);
					   $mail = trim($_POST['mail']);
					    $korisnicko_ime = trim($_POST['user_name']);
						 $pass = trim($_POST['pass']);
						 
			$ime = $_POST['ime'];
			$prezime = $_POST['prezime'];
			$mail = $_POST['mail'];
			$korisnicko_ime = $_POST['user_name'];
			$pass = $_POST['pass'];
			$status = 2;
			
			$stmInsert = $pdo->prepare("INSERT INTO korisnik VALUES(null,?,?,?,?,?,?)");
			
			 $stmInsert->bindValue(1, $ime);
	         $stmInsert->bindValue(2, $prezime);
	         $stmInsert->bindValue(3, $mail);
			 $stmInsert->bindValue(4, $korisnicko_ime);
			 $stmInsert->bindValue(5, $pass);
			 $stmInsert->bindValue(6, $status);
			
			$stmInsert->execute();
			
			if($stmInsert->rowcount() > 0){
		   header('location: admin_home.php');
	   }else{
		   die("Greska pri upisu");
	   }
		
				}
				
				}
		}
				
		*/
		?>   
        
        
        
        <section>
         
         <button><a href="index.php">Ulogujte se ovdje</a></button>
         
        
        </section> 
       
        


</div>  


</body>
</html>
