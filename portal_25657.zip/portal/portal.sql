-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2016 at 11:54 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `korisnicko_ime` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `lozinka` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `korisnicko ime_UNIQUE` (`korisnicko_ime`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `korisnicko_ime`, `lozinka`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `kategorija`
--

CREATE TABLE IF NOT EXISTS `kategorija` (
  `kategorija_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv_kategorije` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `opis_kategorije` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`kategorija_id`),
  UNIQUE KEY `naziv_kategorije_UNIQUE` (`naziv_kategorije`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Informacije o kategorijama vijesti' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `kategorija`
--

INSERT INTO `kategorija` (`kategorija_id`, `naziv_kategorije`, `opis_kategorije`) VALUES
(1, 'politika', 'Sve o politici'),
(2, 'sport', 'Sve o sportu'),
(3, 'kultura', 'sve o kulturi');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `komentar_id` int(11) NOT NULL AUTO_INCREMENT,
  `sadrzaj` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vest_id` int(11) NOT NULL,
  `vrijeme` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`komentar_id`),
  KEY `fk_vest_id_idx` (`vest_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Informacije o svim komentarima na portalu' AUTO_INCREMENT=15 ;

--
-- Dumping data for table `komentar`
--

INSERT INTO `komentar` (`komentar_id`, `sadrzaj`, `vest_id`, `vrijeme`) VALUES
(12, 'Nije to bas tako bilo :)      ', 26, '2016-04-28 11:37:57'),
(13, 'Pokradose nas sve     ', 26, '2016-04-28 11:40:59'),
(14, '  Pobunimo se      ', 26, '2016-04-28 11:43:25');

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE IF NOT EXISTS `korisnik` (
  `korisnik_id` int(11) NOT NULL AUTO_INCREMENT,
  `korisnicko_ime` varchar(17) CHARACTER SET utf8 NOT NULL,
  `e_mail` varchar(30) CHARACTER SET utf8 NOT NULL,
  `lozinka` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`korisnik_id`),
  UNIQUE KEY `korisnicko_ime_UNIQUE` (`korisnicko_ime`),
  UNIQUE KEY `e_mail_UNIQUE` (`e_mail`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Informacije o korisnicima, registrovanim, neregistrovanim i ostalim...\nADMIN STATUS 1\nKORISNIK STATUS 2' AUTO_INCREMENT=28 ;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`korisnik_id`, `korisnicko_ime`, `e_mail`, `lozinka`) VALUES
(23, 'milo', 'milo@gmail.com', '$2y$10$4.N57Gk.'),
(24, 'admin', 'admin@gmail.com', '$2y$10$IDqoCOnn'),
(25, 'marko', 'marko@gmail.com', '$2y$10$n0O7/M1f'),
(26, 'korisnik', 'stijo@gmail.com', 'korisnik'),
(27, 'miki', 'miki@miki.com', 'miki');

-- --------------------------------------------------------

--
-- Stand-in structure for view `kultura`
--
CREATE TABLE IF NOT EXISTS `kultura` (
`vest_id` int(11)
,`naslov` varchar(400)
,`opis` varchar(1000)
,`vrijeme_objave` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `politika`
--
CREATE TABLE IF NOT EXISTS `politika` (
`vest_id` int(11)
,`naslov` varchar(400)
,`opis` varchar(1000)
,`vrijeme_objave` datetime
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `sport`
--
CREATE TABLE IF NOT EXISTS `sport` (
`vest_id` int(11)
,`naslov` varchar(400)
,`opis` varchar(1000)
,`vrijeme_objave` datetime
);
-- --------------------------------------------------------

--
-- Table structure for table `vest`
--

CREATE TABLE IF NOT EXISTS `vest` (
  `vest_id` int(11) NOT NULL AUTO_INCREMENT,
  `naslov` varchar(400) CHARACTER SET utf8 DEFAULT NULL,
  `opis` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `sadrzaj` text CHARACTER SET utf8,
  `kategorija_id` int(11) NOT NULL,
  `vrijeme_objave` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`vest_id`),
  KEY `fk_kategorija_id_idx` (`kategorija_id`),
  FULLTEXT KEY `sadrzaj_idx` (`sadrzaj`,`naslov`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Informacije o vestima' AUTO_INCREMENT=32 ;

--
-- Dumping data for table `vest`
--

INSERT INTO `vest` (`vest_id`, `naslov`, `opis`, `sadrzaj`, `kategorija_id`, `vrijeme_objave`) VALUES
(26, 'Katniću stigla prijava iz Budve: Otimali od države i bogatili se', 'Prijave su protiv ministara Gvozdenovića i Brajovića, bivših čelnika Morskog dobra i vlasnika Stratex i Doguš grupe...     ', 'Grupa budvanskih opozicionih odbornika ponovo je juče specijalnom tužiocu Milivoju Katniću podnijela krivičnu prijavu protiv ministara Branimira Gvozdenovića i Ivana Brajovića, bivših čelnika Morskog dobra i vlasnika Stratex grupe Nila Emilfarba i Doguš grupe Ferita Šahenka, optužujući ih da su na račun građana  omogućili zakupcima Marine Budva da se bogate.\r\n\r\nU prijavi ih terete za zloupotrebu službenog položaja, nesavjesan rad u službi i protivzakonit uticaj, sa elementima organizovanog kriminala.\r\n\r\n“Podnijeli smo krvičnu prijavu i  protiv Upravnog odbora i direktora JP Morsko dobro iz 2007, odgovornih lica u M.C. Marina Budva i odgovornih  u Opštini Budva, a sve zbog krivičnih djela kriminalnog udruživanja, zloupotrebe službenog položaja, nesavjesnog rada u službi, lažnog legitimisanja, obmanjivanja javnosti, umišljaja, zloupotrebe povjerenja, produženog krivičnog djeloa, krivičnog djela stavljanja u monopolistički položaj, građenja objekta bez građevinske dozvole, nepropisnog i nepravilnog izvođenja građevinskih radova, zloupotreba položaja u privrednom poslovanju, zloupotrebe povjerenja sa umišljajem, samovlašća i dovođenja u monopolistički položaj“, kazao je Stevan Džaković (DF) na konferenciji za novinare.       ', 1, '2016-04-28 11:27:48'),
(27, 'Vlada Crne Gore ''progutala'' originalni falsifikat', 'Ruska kompanija "Nega turs" koja je kupila hotel "As" u Perazića dolu kraj Petrovca, dala je lažiranu bankarsku garanciju koju Vlada ne može da naplati, čime dugogodišnji simbol kontroverzne privatizacije hotel "As" dobija novu originalnu dimeniziju   ', 'Ko je odgovoran što je Vlada Crne Gore došla u situaciju da, umjesto naplate bankarske garancije od tri miliona eura, dođe do saznanja da je bankarska garancija ruske Sberbanke falsifikovana.\r\n\r\nRuska kompanija "Nega turs" koja je kupila hotel "As" u Perazića dolu kraj Petrovca, dala je lažiranu bankarsku garanciju koju Vlada ne može da naplati, čime dugogodišnji simbol kontroverzne privatizacije hotel "As" dobija novu originalnu dimeniziju.\r\n\r\nObjašnjavajući fenomen višestruke prevare i pričinjene štete po državu, premijer Milo Đukanović je rekao da Vlada i njene institucije nikada nisu provjeravale bankarske garancije investitora, da sistem ne poznaje proceduru provjere bankarskih garancija, a da je u konkretnom slučaju bankarska garancija ruske kompanije "Nega turs", da će u roku završiti izgradnju hotela "As" u Perazića dolu kod Petrovca, kako je rekao, vizuelno analizirana.\r\n\r\n"Vizuelni pregled garancije nije ukazivao na bilo koju manjkavost ili pokušaj   ', 1, '2016-04-28 11:29:01'),
(28, 'Liverpulu i Sevilji pobjede imperativ', 'Liverpulu i Sevilji pobjeda u Ligi Evrope jedini je put ka plasmanu u Ligu šampiona naredne sezone    ', 'Nakon prvih mečeva u elitnom fudbalskom takmičenju, danas će snage odmjeriti i polufinalisti u Ligi Evrope. Iako se igraju prvi mečevi polufinala, ulog je ogroman, naročito za Liverpul, koji danas gostuje Viljarealu, te Sevilji, koja je gost Šahtjoru. „Crveni” su izgubili šanse da se kroz Premijer ligu domognu utakmica u Ligi šampiona naredne sezone, pa se pobjeda u Ligi Evrope na „Enfildu” doživljava kao posljednja šansa za povratak u evropski vrh.\r\n\r\nU sličnoj situaciji je i dvostruki uzastopni osvajač Lige Evrope, Sevilja, koja je nizom loših rezultata zaostala u trci za četvrto mjesto u Primeri, koje vodi u kvalifikacije za Ligu šampiona.\r\nViljareal, sa druge strane dočekuje Liverpul sa zalihom od četiri boda prednosti u borbi za mjesto koje vodi u razigravanje za Ligu šampiona.\r\n\r\n„Žuta podmornica” je čvrsta i organizovana ekipa i svjesni su toga u Liverpulu.   ', 2, '2016-04-28 11:30:49'),
(29, 'Atletiko ide ka finalu - Saulova magija i odbrana sa Savićem za pobjedu nad Bajernom', 'Atletiko pobijedio Bajern 1:0. Stefan Savić igrao 90 minuta i zaustavio Roberta Levandovskog. Revanš u utorak u Minhenu   ', 'Atletiko sa minimalnom prednošću ide u Minhen - tim Dijega Simeonea savladao je Bajern 1:0, magičnim golom Saula u 11. minutu.\r\n\r\nAtletiko je u drugom poluvremenu, posebno u prvih 25 minuta preživio pravu opsadu, nevjerovatmu dominaciju Bajerna, ali odbrana, u kojoj je dominirao Stefan Savić, potpuno zaustavivši Levandovskog, izdržala je sve i sačuvala mrežu.\r\n\r\nAlaba je bio najbliži izjednačenju, kada je udarcem sa 30-ak metara zatresao prečku, dok je Oblak sjajno zaustavio šut Havija Martinesa.\r\n\r\nKada su izašli iz bunkera, igrači Atletika mogli su da riješe meč, ali je Fernando Tores pogodio stativu.     ', 2, '2016-04-28 11:31:57'),
(30, 'O rumunskom narodu na prostoru Jadrana', 'Ove godine Rumunska akademija slavi vrijedan jubilej - 150 godina postojanja, što je obilježila ciklusom predavanja širom zemlje, a na jednom od njih održanom u Temišvaru, posvećenom rumunskom narodu na području Jadrana, govorio je dr Cvetko Pavlović    ', 'Naučni istraživač i publicista  dr   Cvetko  Pavlović, koji preko 20 godina istražuje Vlahe/Rumune u Crnoj Gori, upravo se vratio iz Rumunije gdje je bio jedan od predavača na velikom naučnom skupu tamošnje akademije nauka i umjetnosti.\r\n\r\nOve godine Rumunska akademija slavi vrijedan jubilej - 150 godina postojanja, što je obilježila ciklusom predavanja širom zemlje, a na jednom od njih održanom u Temišvaru, posvećenom rumunskom narodu na području Jadrana, govorio je  dr  Cvetko  Pavlović.\r\n\r\n“Uvaženom auditorijumu sam predstavio sublimisane rezultate mojih dvodecenijskih istraživanja dubokih istorijskih korijena veza rumunskog i crnogorskog naroda, još od Radula Vlaha, Vlaške crkve na Cetinju iz 1450. i Obodske štamparije 1493, preko vlaških toponima na području Crne Gore i uspostavljanja diplomatskih odnosa Rumunije i Knjaževine Crne Gore 1867. Osvrt je zaključen pomoći koju su narod i Vlada Rumunije poslali Crnoj Gori nakon aprilskog zemljotresa 1979, od koje je podignut Dom zdravlja u Ulcinju”, kazao je za “Vijesti”  dr  Pavlović. Naš sagovornik, koji je do sada objavio preko 20 knjiga, bio je u Temišvaru jedini predstavnik Crne Gore, pored kolega iz Hrvatske, Srbije i Rumunije.      ', 3, '2016-04-28 11:33:07'),
(31, 'Underhillfest: Konkurs do osmog maja', 'Nagrade festivala su Maslačak u međunarodnoj i regionalnoj selekciji, a gosti festivala su priznati umjetnici čiji filmovi su u takmičarskoj selekciji     ', 'Sedmo izdanje Međunarodnog festivala dugometražnog dokumentarnog filma UnderhillFest biće održano početkom juna 2016, a svi talentovani stvaraoci iz regiona i Crne Gore mogu da prijave svoja ostvarenja do nedjelje, osmog maja.\r\n\r\nAplikacije  zajedno sa propozicijama konkursa svi zainteresovani mogu da nađu na Facebook stranici UnderhillFesta www.facebook.com/underhill.fest       ', 3, '2016-04-28 11:34:27');

-- --------------------------------------------------------

--
-- Structure for view `kultura`
--
DROP TABLE IF EXISTS `kultura`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `kultura` AS select `vest`.`vest_id` AS `vest_id`,`vest`.`naslov` AS `naslov`,`vest`.`opis` AS `opis`,`vest`.`vrijeme_objave` AS `vrijeme_objave` from `vest` where (`vest`.`kategorija_id` = 3);

-- --------------------------------------------------------

--
-- Structure for view `politika`
--
DROP TABLE IF EXISTS `politika`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `politika` AS select `vest`.`vest_id` AS `vest_id`,`vest`.`naslov` AS `naslov`,`vest`.`opis` AS `opis`,`vest`.`vrijeme_objave` AS `vrijeme_objave` from `vest` where (`vest`.`kategorija_id` = 1);

-- --------------------------------------------------------

--
-- Structure for view `sport`
--
DROP TABLE IF EXISTS `sport`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sport` AS select `vest`.`vest_id` AS `vest_id`,`vest`.`naslov` AS `naslov`,`vest`.`opis` AS `opis`,`vest`.`vrijeme_objave` AS `vrijeme_objave` from `vest` where (`vest`.`kategorija_id` = 2);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `komentar`
--
ALTER TABLE `komentar`
  ADD CONSTRAINT `fk_vest_id` FOREIGN KEY (`vest_id`) REFERENCES `vest` (`vest_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vest`
--
ALTER TABLE `vest`
  ADD CONSTRAINT `fk_kategorija_id` FOREIGN KEY (`kategorija_id`) REFERENCES `kategorija` (`kategorija_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
