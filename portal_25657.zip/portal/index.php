<?php
session_start();
include_once 'dbconnect.php';

if(isset($_SESSION['userSession'])!="")
{
 header("Location: pocetna.php");
 exit;
}

if(isset($_POST['prosledi']))
{
 $uname = $MySQLi_CON->real_escape_string(trim($_POST['username']));
 $upass = $MySQLi_CON->real_escape_string(trim($_POST['pass']));
 
 $query = $MySQLi_CON->query("SELECT * FROM korisnik WHERE korisnicko_ime='$uname'");
 $row=$query->fetch_array();
 
 if($upass === $row['lozinka'])
 {
  $_SESSION['userSession'] = $row['korisnik_id'];
  header("Location: pocetna.php");
 }
 else
 {
  $msg = "
        user name or password does not exists !";
	
 }
 
 $MySQLi_CON->close();
 
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Naše vreme-početna</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style>
section {
	height: 250px;
	
	}



</style>
</head>

<body>

<div id="wrapper">
        
        <?php
        require('header.inc');
        
        ?>
        
       
        
        
       
        <article>
        <h1>Welcome to DINAMICLY GENERATED CONTENT. PROVIDED TO YOU BY PHP!!!</h1>
       


        
        </article>
        
        <section>
         
         <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
         <h2>Sign in.</h2><hr/>
            <?php
  if(isset($msg)){
   echo $msg;
  }
  ?>
         <label>Korisnicko ime:</label><br>
         <input type="text" name="username" placeholder="Unesite korisnicko ime ili email.." >
         <label>Lozinka:</label>
         <input type="password" name="pass"><br>
         <input type="submit" name="prosledi" value="LOG IN">
         
         
         
         </form>
         
         <p><a href="reg.php">Registracija novih korisnika</a></p>
         <p><a href="sign_in_admin.php">Administratorski panel</a></p>
        </section> 
       
        <?php
        require('footer.inc');
        ?>


</div>  


</body>
</html>
