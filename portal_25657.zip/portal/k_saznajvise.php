<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['userSession']))
{
 header("Location: index.php");
}


$MySQLi_CON->close();
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Saznaj vise</title>
<link rel="stylesheet" type="text/css" href="style.css">

<style>
section {
	height:180px;
	}
</style>
</head>

<body>

<div id="wrapper">
        
        <?php
        require('header.inc');
        
        ?>
        
       <?php
       require('k_nav.php');
       ?>
        
        
       
        
        
        <section>
         
          <!--upucivanje na istu stranu sa osiguranjem od specijalnih karaktera -->
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="GET">
        
       
     <input type="hidden" name="id_vijesti" value="<?php
     $i = $_GET['id'];
	 echo $i;
	 
	 
	 ?>"><br>
        <label>Komentar:</label>
        <br>
        <textarea name="komentar" rows="7" cols="25">
        </textarea>
        <br>
       
        <input type="submit" name="prosledi" value="OBJAVA KOMENTARA"/>
        </form>
        <button><a href="logout.php?logout">logout</a></button>
        </section> 
        <article>
<?php
//Konekcija ka bazi
$dsn = 
"mysql:host=127.0.0.1;dbname=portal;charset=utf8";

try{
   //tunel ka bazi, konekcija, username,pass
   $pdo = new PDO($dsn,"root","");	
	
}catch(PDOException $e){
	
die($e->getMessage());	
}

if(isset($_GET['id'])){
      $id = $_GET['id'];
	  
}


	  
	   $stmtSelect = $pdo->prepare("SELECT * FROM vest Where vest_id = ?");
	  
	   $stmtSelect->bindValue(1, $id);
	   
	  
   	   $stmtSelect->execute();
	   
	   $vest = $stmtSelect->fetch();
	  
	  echo '<h3>' . $vest['naslov'] . '</h3>';
	  echo '<p>' . $vest['sadrzaj'] . '</p>';
	 
	 $pdo = null;
	 
	 ?>
     <p>Komentari korisnika:</p>
	  <article id='komentar'>
     <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "portal";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	if(isset($_GET['prosledi'])){
      $id_vijesti = $_GET['id_vijesti'];
	  $komentar = $_GET['komentar'];
    $sql = "INSERT INTO komentar (sadrzaj, vest_id)
    VALUES ('{$komentar}', '{$id_vijesti}')";
    // use exec() because no results are returned
    $conn->exec($sql);
    header('Location: pocetna.php');
	}
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
?>
      
        
        
		
	<?php
	//selektovanje komentara iz baze
//Konekcija ka bazi
$dsn = 
"mysql:host=127.0.0.1;dbname=portal;charset=utf8";

try{
   //tunel ka bazi, konekcija, username,pass
   $pdo = new PDO($dsn,"root","");	
	
}catch(PDOException $e){
	
die($e->getMessage());	
}

if(isset($_GET['id'])){
      $vijest = $_GET['id'];
	  
}


	  
	   $stmtSelect = $pdo->prepare("SELECT * FROM komentar Where vest_id = ?");
	  
	   $stmtSelect->bindValue(1, $vijest);
	   
	  
   	   $stmtSelect->execute();
	   
	   
	  while($komentar = $stmtSelect->fetch()){
	  echo '<p>' . $komentar['sadrzaj'] . '</p>';
	  echo '<p>' . $komentar['vrijeme'] . '</p><hr>';
	  }
	 $pdo = null;
	 
	 ?>	
	
      </article>
      </article>
       
        <?php
        require("footer.inc");
        ?>


</div>  


</body>
</html>