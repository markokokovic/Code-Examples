<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
/*
//Konekcija ka bazi
$dsn = 
"mysql:host=127.0.0.1;dbname=portal;charset=utf8";

try{
   //tunel ka bazi, konekcija, username,pass
   $pdo = new PDO($dsn,"root","");	
	
}catch(PDOException $e){
	
die($e->getMessage());	
}

if(isset($_GET['id'])){
      $id = $_GET['id'];
	  



	  
	   $stmtDelete = $pdo->prepare("DELETE * FROM vest Where vest_id = ?");
	  
	   $stmtDelete->bindValue(1, $id);
	   
	   $stmtDelete->execute();
}
*/
	  
   	   
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "portal";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
	if(isset($_GET['id'])){
      $id = $_GET['id'];
    // sql to delete a record
    $sql = "DELETE FROM vest WHERE vest_id='{$id}'";

    // use exec() because no results are returned
    $conn->exec($sql);
    header('location: admin_home.php');
	}//od if
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
?>
		
	   
	   
  
	
	 
	 
	  
      </body>
	  </html>