 <nav>
        
        <ul id="list1" type="none">
        
        <li><a href="pocetna.php">Početna</a></li>
        <li><a href="k_politika.php">Politika</a></li>
        <li id="podmeni"><a href="k_sport.php">Sport</a></li>
        <li class="current-item"><a href="k_kultura.php">Kultura</a></li>
        
        
        
        </ul>
       
        </nav>