<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['userSession']))
{
 header("Location: sign_in_admin.php");
}


$MySQLi_CON->close();
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Sport</title>
<link rel="stylesheet" type="text/css" href="style.css">

<style>
button {
	position:absolute;
	left:1000px;
	top: 300px;
	padding:5px;
	
	}
section {
	height:400px;
	}
</style>
</head>

<body>

<div id="wrapper">
        
        <?php
        require('header.inc');
        
        ?>
        
       <?php
       require('nav.inc');
       ?>
        
        
       
        
        
        <section>
         
          <!--upucivanje na istu stranu sa osiguranjem od specijalnih karaktera -->
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="GET">
        
        <label>Naslov vesti:</label>
        <br>
        <textarea name="naslov" rows="3" cols="20"></textarea><br>
        <label>Kratak opis:</label>
        <br>
      <textarea name="opis" rows="5" cols="20" maxlength="600">
       </textarea>
        <br>
        <label>Sadržaj vesti:</label>
        <br>
        <textarea name="sadrzaj" rows="7" cols="20">
        </textarea>
        <br>
        <label>Kategorija:</label>
        <br>
        <select name="kategorija">
        <option value="1">Politika</option>
        <option value="2">Sport</option>
        <option value="3">Kultura</option>
        </select><br><br>
        <input type="submit" name="prosledi" value="OBJAVA VESTI"/>
        </form>
         <p><a href="admin_logout.php?logout">logout</a></p>
        <?php
               //Konekcija ka bazi
       $dsn = 
            "mysql:host=127.0.0.1;dbname=portal;charset=utf8";

       try{
               //tunel ka bazi, konekcija, username,pass
       $pdo = new PDO($dsn,"root","");	
	
       }catch(PDOException $e){
	
       die($e->getMessage());	
       }
        
		//prikupljanje parametara
		if(isset($_GET['prosledi'])){
			$naslov = $_GET['naslov'];
			$opis = $_GET['opis'];
			$sadrzaj = $_GET['sadrzaj'];
			$kategorija = $_GET['kategorija'];
			
			$stmInsert = $pdo->prepare("INSERT INTO vest VALUES(null,?,?,?,?,now())");
			
			 $stmInsert->bindValue(1, $naslov);
	         $stmInsert->bindValue(2, $opis);
	         $stmInsert->bindValue(3, $sadrzaj);
			 $stmInsert->bindValue(4, $kategorija);
			
			$stmInsert->execute();
			
			if($stmInsert->rowcount() > 0){
		   header('location: admin_home.php');
	   }else{
		   die("Greska pri upisu");
	   }
		}
		
	
	?>
		



        </section> 
        <article>
        <?php
        	//prikupljanje iz baze
		$res = $pdo->query("SELECT vest_id,naslov,opis,vrijeme_objave FROM portal.sport");
		
		
	while($r = $res->fetch()){
	      echo "<div><h2>".$r['naslov']."</h2><br>";
		  echo "<p>".$r['opis']."</p><br>";
		  echo "<p>".$r['vrijeme_objave']."</p><br>";
		  echo '<a href="saznajvise.php?id=' . $r['vest_id'] . '">Saznaj vise</a>';
		  echo '<a href="delete.php?id=' . $r['vest_id'] . '"> Obrisi</a>';
		  echo "</div><hr>";
	}

       ?> 
        </article>
       
        <?php
        require('footer.inc');
        ?>


</div>  


</body>
</html>