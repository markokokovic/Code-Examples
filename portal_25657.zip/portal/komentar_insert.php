<?php
		// unos komentaara u bazu
		
               //Konekcija ka bazi
       $dsn = 
            "mysql:host=127.0.0.1;dbname=portal;charset=utf8";

       try{
               //tunel ka bazi, konekcija, username,pass
       $pdo = new PDO($dsn,"root","");	
	
       }catch(PDOException $e){
	
       die($e->getMessage());	
       }
        
		//prikupljanje parametara
		if(isset($_GET['prosledi'])){
			$komentar = $_GET['komentar'];
			
			$stmInsert = $pdo->prepare("INSERT INTO komentar VALUES(null,?,?,null,null)");
			
			 $stmInsert->bindValue(1, $komentar);
	         $stmInsert->bindValue(2, $id);
	         
			
			$stmInsert->execute();
			
			
		}
	$pdo = null;
	?>