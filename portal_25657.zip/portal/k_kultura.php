<?php
session_start();
include_once 'dbconnect.php';

if(!isset($_SESSION['userSession']))
{
 header("Location: index.php");
}


$MySQLi_CON->close();
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Kultura</title>
<link rel="stylesheet" type="text/css" href="style.css">

<style>
button {
	position:absolute;
	left:1000px;
	top: 300px;
	padding:5px;
	
	}
section {
	height:400px;
	}
</style>
</head>

<body>

<div id="wrapper">
        
        <?php
        require('header.inc');
        
        ?>
        
       <?php
       require('k_nav.php');
       ?>
        
        
       
        
        
        <section>
         
         
         <p><a href="logout.php?logout">logout</a></p>

         
        <?php
               //Konekcija ka bazi
       $dsn = 
            "mysql:host=127.0.0.1;dbname=portal;charset=utf8";

       try{
               //tunel ka bazi, konekcija, username,pass
       $pdo = new PDO($dsn,"root","");	
	
       }catch(PDOException $e){
	
       die($e->getMessage());	
       }
        
		
		
	
	?>
		



        </section> 
        <article>
        <?php
        	//prikupljanje iz baze
		$res = $pdo->query("SELECT vest_id,naslov,opis,vrijeme_objave FROM portal.kultura");
		
		
	while($r = $res->fetch()){
	      echo "<div><h2>".$r['naslov']."</h2><br>";
		  echo "<p>".$r['opis']."</p><br>";
		  echo "<p>".$r['vrijeme_objave']."</p><br>";
		  echo '<a href="k_saznajvise.php?id=' . $r['vest_id'] . '"><img style="height:40px; width:130px;" src="more.png"></a>';
		  
		  echo "</div><hr>";
	}

       ?> 
        </article>
       
        <?php
        require('footer.inc');
        ?>


</div>  


</body>
</html>